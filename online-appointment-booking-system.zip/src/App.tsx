import React, { useState, useEffect } from 'react';
import Auth from './components/Auth';
import CustomerDashboard from './components/CustomerDashboard';
import ProviderDashboard from './components/ProviderDashboard';
import { User } from './types';
import { RefreshCw } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // Attempt local session restoration on load
  useEffect(() => {
    const storedToken = localStorage.getItem('bookease_token');
    
    if (storedToken) {
      fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${storedToken}`
        }
      })
      .then(res => {
        if (res.ok) {
          return res.json();
        } else {
          throw new Error('Authorized session expired.');
        }
      })
      .then(data => {
        setUser(data.user);
        setToken(storedToken);
      })
      .catch(err => {
        console.warn('Session restoring warning:', err);
        localStorage.removeItem('bookease_token');
      })
      .finally(() => {
        setLoading(false);
      });
    } else {
      setLoading(false);
    }
  }, []);

  const handleAuthSuccess = (authUser: User, authToken: string) => {
    setUser(authUser);
    setToken(authToken);
    localStorage.setItem('bookease_token', authToken);
  };

  const handleLogout = async () => {
    if (token) {
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
      } catch (e) {
        console.error('Logout request failure:', e);
      }
    }
    setUser(null);
    setToken(null);
    localStorage.removeItem('bookease_token');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center font-sans text-slate-800" id="loading_screen">
        <div className="text-center space-y-4">
          <div className="inline-flex h-12 w-12 rounded-xl bg-indigo-100 items-center justify-center text-indigo-600 animate-spin">
            <RefreshCw className="w-6 h-6" />
          </div>
          <p className="text-sm font-semibold text-slate-600">Restoring secure user session...</p>
        </div>
      </div>
    );
  }

  // Router based on user authentication state & user profile type
  if (!user || !token) {
    return <Auth onAuthSuccess={handleAuthSuccess} />;
  }

  if (user.role === 'provider') {
    return (
      <ProviderDashboard 
        user={user} 
        onLogout={handleLogout} 
        token={token} 
      />
    );
  }

  return (
    <CustomerDashboard 
      user={user} 
      onLogout={handleLogout} 
      token={token} 
    />
  );
}
