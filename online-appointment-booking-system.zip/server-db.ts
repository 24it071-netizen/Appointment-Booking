import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { User, Service, Appointment, AppointmentStatus } from './src/types';

// Database raw representation
interface DBStructure {
  users: Array<User & { passwordHash: string }>;
  services: Service[];
  appointments: Appointment[];
  sessions: { [token: string]: { userId: string; expiresAt: number } };
}

const DB_FILE = path.join(process.cwd(), 'database.json');

// Initialize database with seed data if it doesn't exist
const initialData: DBStructure = {
  users: [
    {
      id: 'usr_prov_1',
      name: 'Dr. Jane Smith (Wellness Center)',
      email: 'provider@example.com',
      role: 'provider',
      createdAt: new Date().toISOString(),
      passwordHash: hashPassword('provider123')
    },
    {
      id: 'usr_cust_1',
      name: 'John Doe',
      email: 'customer@example.com',
      role: 'customer',
      createdAt: new Date().toISOString(),
      passwordHash: hashPassword('customer123')
    }
  ],
  services: [
    {
      id: 'srv_1',
      name: 'Physiotherapy Consultation',
      description: 'Comprehensive initial physical assessment, movement analysis, and tailored rehabilitation plan.',
      duration: 60,
      price: 120,
      category: 'Health & Wellness',
      providerId: 'usr_prov_1',
      providerName: 'Dr. Jane Smith (Wellness Center)',
      createdAt: new Date().toISOString()
    },
    {
      id: 'srv_2',
      name: 'Deep Tissue Massage Therapy',
      description: 'Targeted massage therapy focused on releasing chronic muscle tension and tightness.',
      duration: 45,
      price: 85,
      category: 'Massage & Relaxation',
      providerId: 'usr_prov_1',
      providerName: 'Dr. Jane Smith (Wellness Center)',
      createdAt: new Date().toISOString()
    },
    {
      id: 'srv_3',
      name: 'Acupuncture Healing Session',
      description: 'Traditional acupuncture treatment aimed at stress relief, pain management, and inner balance.',
      duration: 30,
      price: 75,
      category: 'Alternative Medicine',
      providerId: 'usr_prov_1',
      providerName: 'Dr. Jane Smith (Wellness Center)',
      createdAt: new Date().toISOString()
    }
  ],
  appointments: [
    {
      id: 'apt_1',
      serviceId: 'srv_1',
      serviceName: 'Physiotherapy Consultation',
      customerId: 'usr_cust_1',
      customerName: 'John Doe',
      customerEmail: 'customer@example.com',
      providerId: 'usr_prov_1',
      providerName: 'Dr. Jane Smith (Wellness Center)',
      date: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0], // 2 days in future
      timeSlot: '10:00 AM',
      duration: 60,
      price: 120,
      status: 'pending',
      notes: 'Please assess lower back tension from running.',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'apt_2',
      serviceId: 'srv_2',
      serviceName: 'Deep Tissue Massage Therapy',
      customerId: 'usr_cust_1',
      customerName: 'John Doe',
      customerEmail: 'customer@example.com',
      providerId: 'usr_prov_1',
      providerName: 'Dr. Jane Smith (Wellness Center)',
      date: new Date(Date.now() - 86400000 * 3).toISOString().split('T')[0], // 3 days in past
      timeSlot: '02:30 PM',
      duration: 45,
      price: 85,
      status: 'completed',
      notes: 'Routine recovery session.',
      createdAt: new Date(Date.now() - 86400000 * 4).toISOString(),
      updatedAt: new Date(Date.now() - 86400000 * 3).toISOString()
    }
  ],
  sessions: {}
};

// Simple visual helpers to hash password with SHA256
export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

class DatabaseManager {
  private data: DBStructure;

  constructor() {
    this.data = this.load();
  }

  private load(): DBStructure {
    try {
      if (fs.existsSync(DB_FILE)) {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(fileContent);
        // Ensure standard keys exist
        return {
          users: parsed.users || [],
          services: parsed.services || [],
          appointments: parsed.appointments || [],
          sessions: parsed.sessions || {}
        };
      }
    } catch (e) {
      console.error('Error reading database file, resetting to defaults', e);
    }
    this.saveData(initialData);
    return JSON.parse(JSON.stringify(initialData)); // Deep clone
  }

  private saveData(data: DBStructure): void {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Error saving database file', e);
    }
  }

  private persist(): void {
    this.saveData(this.data);
  }

  // --- AUTH OPERATIONS ---
  public registerUser(name: string, email: string, role: 'customer' | 'provider', passwordPlain: string): User {
    const emailNormalized = email.toLowerCase().trim();
    const existing = this.data.users.find(u => u.email.toLowerCase() === emailNormalized);
    if (existing) {
      throw new Error('Email address already registered.');
    }

    const id = 'usr_' + crypto.randomUUID().replace(/-/g, '').substring(0, 12);
    const passwordHash = hashPassword(passwordPlain);
    const newUser = {
      id,
      name: name.trim(),
      email: emailNormalized,
      role,
      createdAt: new Date().toISOString(),
      passwordHash
    };

    this.data.users.push(newUser);
    this.persist();

    const { passwordHash: _, ...userSafe } = newUser;
    return userSafe;
  }

  public authenticateUser(email: string, passwordPlain: string): { user: User; token: string } {
    const emailNormalized = email.toLowerCase().trim();
    const userMatched = this.data.users.find(u => u.email.toLowerCase() === emailNormalized);
    if (!userMatched) {
      throw new Error('Invalid email or password.');
    }

    const verificationHash = hashPassword(passwordPlain);
    if (userMatched.passwordHash !== verificationHash) {
      throw new Error('Invalid email or password.');
    }

    // Create unique token
    const token = 'tok_' + crypto.randomBytes(24).toString('hex');
    const expiresAt = Date.now() + (86400000 * 7); // 7 days expiration

    this.data.sessions[token] = {
      userId: userMatched.id,
      expiresAt
    };
    this.persist();

    const { passwordHash: _, ...userSafe } = userMatched;
    return {
      user: userSafe,
      token
    };
  }

  public getUserByToken(token: string): User | null {
    const session = this.data.sessions[token];
    if (!session) return null;

    if (Date.now() > session.expiresAt) {
      delete this.data.sessions[token];
      this.persist();
      return null;
    }

    const user = this.data.users.find(u => u.id === session.userId);
    if (!user) return null;

    const { passwordHash: _, ...userSafe } = user;
    return userSafe;
  }

  public logoutUser(token: string): void {
    if (this.data.sessions[token]) {
      delete this.data.sessions[token];
      this.persist();
    }
  }

  // --- SERVICE OPERATIONS ---
  public getServices(): Service[] {
    return this.data.services;
  }

  public createService(serviceData: Omit<Service, 'id' | 'createdAt'>): Service {
    const id = 'srv_' + crypto.randomUUID().replace(/-/g, '').substring(0, 12);
    const newService: Service = {
      ...serviceData,
      id,
      createdAt: new Date().toISOString()
    };
    this.data.services.push(newService);
    this.persist();
    return newService;
  }

  public updateService(id: string, providerId: string, serviceData: Partial<Omit<Service, 'id' | 'providerId' | 'createdAt'>>): Service {
    const index = this.data.services.findIndex(s => s.id === id);
    if (index === -1) {
      throw new Error('Service not found.');
    }
    const serviceObj = this.data.services[index];
    if (serviceObj.providerId !== providerId) {
      throw new Error('Access denied. You do not own this service.');
    }

    const updated: Service = {
      ...serviceObj,
      ...serviceData,
      id,
      providerId,
      providerName: serviceObj.providerName, // Lock provider name
      createdAt: serviceObj.createdAt
    };

    this.data.services[index] = updated;
    this.persist();
    return updated;
  }

  public deleteService(id: string, providerId: string): void {
    const index = this.data.services.findIndex(s => s.id === id);
    if (index === -1) {
      throw new Error('Service not found.');
    }
    if (this.data.services[index].providerId !== providerId) {
      throw new Error('Access denied. You do not own this service.');
    }

    // Filter appointments for deleted service - in small apps let's just keep history but filter service
    this.data.services.splice(index, 1);
    this.persist();
  }

  // --- APPOINTMENT OPERATIONS ---
  public getAppointments(userId: string, role: 'customer' | 'provider'): Appointment[] {
    if (role === 'provider') {
      return this.data.appointments.filter(a => a.providerId === userId);
    } else {
      return this.data.appointments.filter(a => a.customerId === userId);
    }
  }

  public bookAppointment(appointmentData: {
    serviceId: string;
    customerId: string;
    customerName: string;
    customerEmail: string;
    date: string;
    timeSlot: string;
    notes?: string;
  }): Appointment {
    const service = this.data.services.find(s => s.id === appointmentData.serviceId);
    if (!service) {
      throw new Error('Service requested is not available.');
    }

    // Check availability slot collision on the same date and time slot for THIS provider.
    const isConflict = this.data.appointments.some(a => 
      a.providerId === service.providerId &&
      a.date === appointmentData.date &&
      a.timeSlot === appointmentData.timeSlot &&
      ['accepted', 'pending'].includes(a.status)
    );

    if (isConflict) {
      throw new Error('This time slot has already been reserved. Please choose another slot.');
    }

    const id = 'apt_' + crypto.randomUUID().replace(/-/g, '').substring(0, 12);
    const newAppointment: Appointment = {
      id,
      serviceId: service.id,
      serviceName: service.name,
      customerId: appointmentData.customerId,
      customerName: appointmentData.customerName,
      customerEmail: appointmentData.customerEmail,
      providerId: service.providerId,
      providerName: service.providerName,
      date: appointmentData.date,
      timeSlot: appointmentData.timeSlot,
      duration: service.duration,
      price: service.price,
      status: 'pending',
      notes: appointmentData.notes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.data.appointments.push(newAppointment);
    this.persist();
    return newAppointment;
  }

  public updateAppointmentStatus(
    appointmentId: string, 
    userId: string, 
    role: 'customer' | 'provider', 
    newStatus: AppointmentStatus
  ): Appointment {
    const index = this.data.appointments.findIndex(a => a.id === appointmentId);
    if (index === -1) {
      throw new Error('Appointment not found.');
    }

    const apt = this.data.appointments[index];

    // Authorization checks
    if (role === 'provider') {
      if (apt.providerId !== userId) {
        throw new Error('Access denied to this appointment.');
      }
      // Providers can accept, reject, complete appointments
      if (!['accepted', 'rejected', 'completed', 'cancelled'].includes(newStatus)) {
        throw new Error('Invalid status action.');
      }
    } else {
      if (apt.customerId !== userId) {
        throw new Error('Access denied to this appointment.');
      }
      // Customers can only cancel their pending/accepted appointments
      if (newStatus !== 'cancelled') {
        throw new Error('Customers can only cancel appointments.');
      }
    }

    apt.status = newStatus;
    apt.updatedAt = new Date().toISOString();
    this.data.appointments[index] = apt;
    this.persist();
    return apt;
  }
}

export const dbManager = new DatabaseManager();
