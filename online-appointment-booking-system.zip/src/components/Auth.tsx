import React, { useState } from 'react';
import { User, AuthResponse } from '../types';
import { Calendar, Shield, Mail, Lock, User as UserIcon, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AuthProps {
  onAuthSuccess: (user: User, token: string) => void;
}

export default function Auth({ onAuthSuccess }: AuthProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [role, setRole] = useState<'customer' | 'provider'>('customer');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    const endpoint = isLogin ? '/api/auth/login' : '/api/auth/register';
    const payload = isLogin 
      ? { email, password } 
      : { name, email, role, password };

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Authentication failed. Please verify credentials.');
      }

      if (isLogin) {
        setSuccess('Login successful! Redirecting...');
        setTimeout(() => {
          onAuthSuccess(data.user, data.token);
        }, 1000);
      } else {
        setSuccess('Registration successful! Logging you in...');
        setTimeout(() => {
          onAuthSuccess(data.user, data.token);
        }, 1000);
      }
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4 py-12 sm:px-6 lg:px-8" id="auth_container">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-2xl shadow-xl border border-slate-100">
        
        {/* Branding & Header */}
        <div className="text-center">
          <div className="inline-flex items-center justify-center h-16 w-16 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-600 mb-4 shadow-sm" id="auth_brand_logo">
            <Calendar className="w-8 h-8" />
          </div>
          <h2 className="text-3xl font-bold font-sans tracking-tight text-slate-900" id="auth_title">
            BookEase
          </h2>
          <p className="mt-2 text-sm text-slate-500 font-sans" id="auth_subtitle">
            {isLogin 
              ? 'Access your unified appointment scheduling dashboard' 
              : 'Create a free client or provider profile to get started'}
          </p>
        </div>

        {/* Info Feedback Modals */}
        <AnimatePresence mode="wait">
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex items-center gap-3 p-4 bg-rose-50 border border-rose-100 text-rose-700 rounded-xl text-sm"
              id="auth_error_alert"
            >
              <AlertCircle className="w-5 h-5 shrink-0" />
              <span>{error}</span>
            </motion.div>
          )}

          {success && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex items-center gap-3 p-4 bg-emerald-50 border border-emerald-100 text-emerald-700 rounded-xl text-sm"
              id="auth_success_alert"
            >
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <span>{success}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Tab Controls for Login / Register */}
        <div className="flex bg-slate-100 p-1 rounded-xl" id="auth_mode_selector">
          <button
            type="button"
            className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
              isLogin 
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200/50' 
                : 'text-slate-500 hover:text-slate-900'
            }`}
            onClick={() => {
              setIsLogin(true);
              setError(null);
            }}
            id="btn_select_login"
          >
            Login
          </button>
          <button
            type="button"
            className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
              !isLogin 
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200/50' 
                : 'text-slate-500 hover:text-slate-900'
            }`}
            onClick={() => {
              setIsLogin(false);
              setError(null);
            }}
            id="btn_select_register"
          >
            Sign Up
          </button>
        </div>

        {/* Auth Input Form */}
        <form onSubmit={handleSubmit} className="space-y-5" id="auth_form">
          
          {/* Role Selection (Only shown for Registration) */}
          {!isLogin && (
            <div className="space-y-2" id="role_selector_group">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider block">
                User Profile Type
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setRole('customer')}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                    role === 'customer'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-700 font-semibold ring-2 ring-indigo-600/10'
                      : 'border-slate-200 text-slate-600 hover:border-slate-300'
                  }`}
                  id="btn_role_customer"
                >
                  <UserIcon className="w-5 h-5 mb-1" />
                  <span className="text-xs">Client (Customer)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRole('provider')}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                    role === 'provider'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-700 font-semibold ring-2 ring-indigo-600/10'
                      : 'border-slate-200 text-slate-600 hover:border-slate-300'
                  }`}
                  id="btn_role_provider"
                >
                  <Shield className="w-5 h-5 mb-1" />
                  <span className="text-xs">Business Provider</span>
                </button>
              </div>
            </div>
          )}

          {/* Full Name Input (Only shown for Registration) */}
          {!isLogin && (
            <div className="space-y-1" id="name_input_group">
              <label htmlFor="name_input" className="text-sm font-medium text-slate-700 block">
                Full Name or Business Name
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <UserIcon className="w-5 h-5" />
                </div>
                <input
                  id="name_input"
                  type="text"
                  required
                  placeholder={role === 'provider' ? 'e.g., Premier Health Clinic' : 'e.g., John Doe'}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 transition-all text-sm"
                />
              </div>
            </div>
          )}

          {/* Email Address Input */}
          <div className="space-y-1" id="email_input_group">
            <label htmlFor="email_input" className="text-sm font-medium text-slate-700 block">
              Email Address / Username
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Mail className="w-5 h-5" />
              </div>
              <input
                id="email_input"
                type="email"
                required
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 transition-all text-sm"
              />
            </div>
          </div>

          {/* Password Input */}
          <div className="space-y-1" id="password_input_group">
            <label htmlFor="password_input" className="text-sm font-medium text-slate-700 block">
              Secure Password
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-5 h-5" />
              </div>
              <input
                id="password_input"
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 transition-all text-sm"
              />
            </div>
            {!isLogin && (
              <p className="text-xs text-slate-400 mt-1">Must be at least 6 characters long.</p>
            )}
          </div>

          {/* Submit Action Button */}
          <button
            type="submit"
            disabled={loading}
            className={`w-full py-3 px-4 rounded-xl text-white font-medium shadow-md transition-all flex items-center justify-center gap-2 ${
              loading 
                ? 'bg-indigo-400 cursor-not-allowed' 
                : 'bg-indigo-600 hover:bg-indigo-700 hover:shadow-indigo-600/10 active:scale-[0.99]'
            }`}
            id="btn_submit_auth"
          >
            {loading ? (
              <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
            ) : (
              <>
                <span>{isLogin ? 'Sign In' : 'Create Account'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Demo Credentials Helper */}
        <div className="border-t border-slate-100 pt-4 mt-6 text-center" id="demo_helper_panel">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-2">Demo Access Credentials</p>
          <div className="grid grid-cols-2 gap-2 text-left">
            <div 
              className="bg-slate-50 p-2.5 rounded-lg border border-slate-100 cursor-pointer hover:bg-slate-100 transition-all"
              onClick={() => {
                setIsLogin(true);
                setEmail('customer@example.com');
                setPassword('customer123');
              }}
              title="Click to auto-fill"
              id="hint_customer_autofill"
            >
              <p className="text-xs font-bold text-slate-600">Client Profile</p>
              <p className="text-[10px] text-slate-500 font-mono truncate">customer@example.com</p>
              <p className="text-[10px] text-slate-500 font-mono">Pass: customer123</p>
            </div>
            <div 
              className="bg-slate-50 p-2.5 rounded-lg border border-slate-100 cursor-pointer hover:bg-slate-100 transition-all"
              onClick={() => {
                setIsLogin(true);
                setEmail('provider@example.com');
                setPassword('provider123');
              }}
              title="Click to auto-fill"
              id="hint_provider_autofill"
            >
              <p className="text-xs font-bold text-slate-600">Business Profile</p>
              <p className="text-[10px] text-slate-500 font-mono truncate">provider@example.com</p>
              <p className="text-[10px] text-slate-500 font-mono font-sans">Pass: provider123</p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
