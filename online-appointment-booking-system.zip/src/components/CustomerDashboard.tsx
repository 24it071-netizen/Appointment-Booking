import React, { useState, useEffect } from 'react';
import { User, Service, Appointment } from '../types';
import { 
  Calendar, Clock, CheckCircle, XCircle, AlertCircle, 
  HelpCircle, Search, LogOut, DollarSign, Tag, ListFilter, 
  Plus, CalendarDays, ClipboardList, CreditCard, RefreshCw, MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CustomerDashboardProps {
  user: User;
  onLogout: () => void;
  token: string;
}

const AVAILABLE_TIME_SLOTS = [
  '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', 
  '01:30 PM', '02:30 PM', '03:30 PM', '04:30 PM', '05:30 PM'
];

export default function CustomerDashboard({ user, onLogout, token }: CustomerDashboardProps) {
  const [services, setServices] = useState<Service[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loadingServices, setLoadingServices] = useState(false);
  const [loadingAppointments, setLoadingAppointments] = useState(false);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [categories, setCategories] = useState<string[]>([]);

  // Booking state
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [bookingDate, setBookingDate] = useState('');
  const [bookingSlot, setBookingSlot] = useState('');
  const [bookingNotes, setBookingNotes] = useState('');
  const [submittingBooking, setSubmittingBooking] = useState(false);
  const [bookingError, setBookingError] = useState<string | null>(null);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  // UI state
  const [activeTab, setActiveTab] = useState<'services' | 'history'>('services');

  // Interactive non-blocking confirmation dialog state
  const [cancelCandidateId, setCancelCandidateId] = useState<string | null>(null);
  const [errorNotification, setErrorNotification] = useState<string | null>(null);

  // Load Services & Appointments
  const loadServices = async () => {
    setLoadingServices(true);
    try {
      const response = await fetch('/api/services');
      const data = await response.json();
      if (response.ok) {
        setServices(data);
        // Extract unique categories
        const cats = Array.from(new Set(data.map((s: Service) => s.category))) as string[];
        setCategories(['All', ...cats]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingServices(false);
    }
  };

  const loadAppointments = async () => {
    setLoadingAppointments(true);
    try {
      const response = await fetch('/api/appointments', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        // Sort appointments by date & time slot descending
        const sorted = data.sort((a: Appointment, b: Appointment) => {
          const datetimeA = new Date(`${a.date}`).getTime();
          const datetimeB = new Date(`${b.date}`).getTime();
          return datetimeB - datetimeA;
        });
        setAppointments(sorted);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingAppointments(false);
    }
  };

  useEffect(() => {
    loadServices();
    loadAppointments();
  }, [token]);

  const handleBookAppointment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedService || !bookingDate || !bookingSlot) {
      setBookingError('Please select a valid service, date, and preferred time.');
      return;
    }

    setSubmittingBooking(true);
    setBookingError(null);

    try {
      const response = await fetch('/api/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          serviceId: selectedService.id,
          date: bookingDate,
          timeSlot: bookingSlot,
          notes: bookingNotes
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Server error occurred during booking.');
      }

      setBookingSuccess(true);
      setBookingDate('');
      setBookingSlot('');
      setBookingNotes('');
      setSelectedService(null);
      loadAppointments();

      // Clear success alert after 4 seconds
      setTimeout(() => {
        setBookingSuccess(false);
      }, 4000);
    } catch (err: any) {
      setBookingError(err.message || 'Booking submission failed.');
    } finally {
      setSubmittingBooking(false);
    }
  };

  const cancelAppointment = async (id: string) => {
    try {
      const response = await fetch(`/api/appointments/${id}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ status: 'cancelled' })
      });

      if (response.ok) {
        loadAppointments();
        setCancelCandidateId(null);
      } else {
        const errData = await response.json();
        setErrorNotification(errData.error || 'Failed to cancel appointment.');
      }
    } catch (e) {
      console.error(e);
      setErrorNotification('Communication with the server was interrupted. Please retry.');
    }
  };

  // Safe checks for date inputs - prevent booking in the past
  const getMinDateString = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  // Fitler services by search and category
  const filteredServices = services.filter(srv => {
    const matchesSearch = srv.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          srv.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          srv.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || srv.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800" id="customer_dashboard_view">
      {/* Dashboard Top bar / Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm" id="cust_header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold" id="logo_container">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xl font-bold tracking-tight text-slate-900">BookEase</span>
                <span className="ml-2 text-xs bg-indigo-50 border border-indigo-100 text-indigo-700 font-semibold px-2 py-0.5 rounded-full">Client Workspace</span>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-semibold text-slate-800">{user.name}</p>
                <p className="text-xs text-slate-400">{user.email}</p>
              </div>
              <div className="h-9 w-px bg-slate-200 hidden sm:block"></div>
              <button
                onClick={onLogout}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-50 transition-all text-sm font-medium"
                id="btn_logout"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* Main Core Dashboard Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Welcome and Tabs navigation */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight" id="welcome_message">
              Hi, {user.name.split(' ')[0]} ⚡
            </h1>
            <p className="text-sm text-slate-500">
              Browse professional services, manage upcoming bookings, and coordinate schedule instantly.
            </p>
          </div>

          <div className="flex bg-slate-100 p-1 rounded-xl w-full md:w-auto border border-slate-200/40" id="view_tabs">
            <button
              onClick={() => setActiveTab('services')}
              className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'services'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200/50'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              id="tab_services"
            >
              <Calendar className="w-4 h-4" />
              Available Offerings
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'history'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200/50'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              id="tab_history"
            >
              <CalendarDays className="w-4 h-4" />
              My Bookings
              {appointments.length > 0 && (
                <span className="bg-indigo-600 text-white text-[10px] h-5 min-w-5 px-1 flex items-center justify-center rounded-full font-bold">
                  {appointments.length}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Dynamic Alert Messages */}
        <AnimatePresence>
          {bookingSuccess && (
            <motion.div
              initial={{ opacity: 0, height: 0, marginBottom: 0 }}
              animate={{ opacity: 1, height: 'auto', marginBottom: 24 }}
              exit={{ opacity: 0, height: 0, marginBottom: 0 }}
              className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl flex items-start gap-3"
              id="main_booking_alert_success"
            >
              <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-emerald-950">Awesome, appointment requested!</h4>
                <p className="text-xs text-emerald-700 mt-1">
                  Your booking request is pending confirmation. You can monitor the live response status in "My Bookings" tab.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Tab content screens */}
        <div id="tab_contents">
          {activeTab === 'services' ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Left Column: List of Services (Span 2) */}
              <div className="lg:col-span-2 space-y-6">
                
                {/* Search & Category filter bar */}
                <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200 flex flex-col sm:flex-row gap-3">
                  <div className="relative flex-1">
                    <Search className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 w-5 h-5 my-auto" />
                    <input
                      type="text"
                      placeholder="Search for physical, wellness, or relax offerings..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 transition-all text-sm"
                      id="search_services_input"
                    />
                  </div>

                  {categories.length > 1 && (
                    <div className="flex items-center gap-2">
                      <ListFilter className="w-4 h-4 text-slate-400 shrink-0" />
                      <select
                        value={selectedCategory}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                        className="bg-white border border-slate-200 rounded-lg py-2 pl-3 pr-8 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-sm"
                        id="category_filter_dropdown"
                      >
                        {categories.map((cat, idx) => (
                          <option key={idx} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                {/* Offerings Grid */}
                {loadingServices ? (
                  <div className="flex flex-col items-center justify-center py-20 bg-white rounded-xl border border-slate-200 border-dashed">
                    <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin mb-3" />
                    <p className="text-sm font-medium text-slate-500">Querying live services inventory...</p>
                  </div>
                ) : filteredServices.length === 0 ? (
                  <div className="text-center py-20 bg-white rounded-xl border border-slate-200 border-dashed">
                    <HelpCircle className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                    <h3 className="text-base font-bold text-slate-800">No Services Found</h3>
                    <p className="text-sm text-slate-400 mt-1 max-w-md mx-auto">
                      Adjust your filter settings or search string to verify other professional offerings.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {filteredServices.map((srv) => {
                      const isSelected = selectedService?.id === srv.id;
                      return (
                        <div 
                          key={srv.id}
                          className={`bg-white rounded-xl p-5 border transition-all duration-200 flex flex-col justify-between ${
                            isSelected 
                              ? 'border-indigo-600 ring-4 ring-indigo-50 hover:shadow-indigo-50' 
                              : 'border-slate-200 hover:shadow-md hover:border-slate-300'
                          }`}
                          id={`srv_card_${srv.id}`}
                        >
                          <div>
                            <div className="flex justify-between items-start gap-2 mb-2">
                              <span className="inline-block text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 rounded-full px-2.5 py-0.5 uppercase tracking-wide">
                                {srv.category}
                              </span>
                              <span className="text-lg font-extrabold text-slate-900">${srv.price}</span>
                            </div>

                            <h3 className="font-bold text-slate-900 text-base mb-1 line-clamp-1">{srv.name}</h3>
                            <p className="text-xs text-slate-500 mb-3 font-medium flex items-center gap-1">
                              <span>By: {srv.providerName}</span>
                            </p>
                            <p className="text-xs text-slate-600 line-clamp-3 mb-4 leading-relaxed h-12">
                              {srv.description}
                            </p>
                          </div>

                          <div className="border-t border-slate-100 pt-3 flex justify-between items-center bg-transparent mt-2">
                            <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5 text-slate-400" />
                              {srv.duration} mins
                            </span>

                            <button
                              type="button"
                              onClick={() => {
                                setSelectedService(srv);
                                setBookingError(null);
                                // Automatically scroll to the booking widget on mobile view
                                if (window.innerWidth < 1024) {
                                  document.getElementById('booking_form_wrapper')?.scrollIntoView({ behavior: 'smooth' });
                                }
                              }}
                              className={`text-xs font-semibold px-4 py-2 rounded-lg transition-all ${
                                isSelected
                                  ? 'bg-indigo-600 text-white'
                                  : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-100'
                              }`}
                              id={`btn_select_srv_${srv.id}`}
                            >
                              {isSelected ? 'Selected' : 'Book Session'}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Right Column: Interactive Booking Panel */}
              <div className="lg:col-span-1" id="booking_form_wrapper">
                <div className="bg-white border border-slate-200 rounded-xl p-5 sticky top-24 shadow-sm">
                  
                  <div className="border-b border-slate-100 pb-3 mb-4">
                    <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                      <Plus className="w-5 h-5 text-indigo-600" />
                      Configure Booking
                    </h2>
                    <p className="text-xs text-slate-400 mt-1">Select an offering card from the left to adjust calendar slots.</p>
                  </div>

                  {selectedService ? (
                    <form onSubmit={handleBookAppointment} className="space-y-4">
                      
                      {/* Selection Summary */}
                      <div className="bg-slate-50 border border-slate-100 rounded-lg p-3">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Active Choice</p>
                        <h4 className="font-bold text-xs text-slate-950 truncate mt-0.5">{selectedService.name}</h4>
                        <div className="flex gap-4 mt-2 text-xs font-medium text-slate-500">
                          <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {selectedService.duration} min</span>
                          <span className="flex items-center gap-1"><DollarSign className="w-3.5 h-3.5" /> ${selectedService.price}</span>
                        </div>
                      </div>

                      {/* Date selection */}
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-600 block">Select Date</label>
                        <div className="relative">
                          <input
                            type="date"
                            required
                            min={getMinDateString()}
                            value={bookingDate}
                            onChange={(e) => setBookingDate(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-xs text-slate-900"
                            id="input_booking_date"
                          />
                        </div>
                      </div>

                      {/* Time slot selection */}
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-600 block">Select Time Slot</label>
                        <div className="grid grid-cols-3 gap-1.5">
                          {AVAILABLE_TIME_SLOTS.map((slot) => (
                            <button
                              type="button"
                              key={slot}
                              onClick={() => setBookingSlot(slot)}
                              className={`py-1.5 rounded text-[11px] font-medium transition-all text-center border ${
                                bookingSlot === slot
                                  ? 'bg-indigo-600 text-white border-indigo-600'
                                  : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
                              }`}
                            >
                              {slot}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Optional notes */}
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-600 block">Additional Notes (Optional)</label>
                        <textarea
                          rows={3}
                          placeholder="Provide context, special conditions, or symptoms..."
                          value={bookingNotes}
                          onChange={(e) => setBookingNotes(e.target.value)}
                          className="w-full p-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-xs"
                          id="textarea_booking_notes"
                        />
                      </div>

                      {bookingError && (
                        <div className="p-3 bg-rose-50 border border-rose-100 text-rose-700 rounded-lg text-xs flex items-start gap-1.5">
                          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                          <span>{bookingError}</span>
                        </div>
                      )}

                      <button
                        type="submit"
                        disabled={submittingBooking || !bookingDate || !bookingSlot}
                        className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-white shadow transition-all ${
                          submittingBooking || !bookingDate || !bookingSlot
                            ? 'bg-indigo-400 cursor-not-allowed'
                            : 'bg-indigo-600 hover:bg-indigo-700'
                        }`}
                        id="btn_submit_booking"
                      >
                        {submittingBooking ? 'Saving Slot...' : 'Reserve Appointment'}
                      </button>

                    </form>
                  ) : (
                    <div className="text-center py-12 px-4 bg-slate-50 rounded-xl border border-slate-200 border-dashed">
                      <ClipboardList className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                      <p className="text-xs font-semibold text-slate-500">Pick a Service</p>
                      <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                        Choose your professional therapist or treatment on the left to reveal available appointment slots.
                      </p>
                    </div>
                  )}

                </div>
              </div>

            </div>
          ) : (
            
            /* History & Reservations View List */
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <div className="p-5 border-b border-slate-100 flex justify-between items-center">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">Appointment Ledger</h2>
                  <p className="text-xs text-slate-400">Track and view history status of your custom reservations.</p>
                </div>
                <button
                  onClick={loadAppointments}
                  className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-slate-900 hover:bg-slate-50 transition-all"
                  title="Reload Bookings Ledger"
                >
                  <RefreshCw className={`w-4 h-4 ${loadingAppointments ? 'animate-spin' : ''}`} />
                </button>
              </div>

              {loadingAppointments ? (
                <div className="py-20 text-center">
                  <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin mx-auto mb-3" />
                  <p className="text-sm font-medium text-slate-400">Compiling your appointments ledger...</p>
                </div>
              ) : appointments.length === 0 ? (
                <div className="py-20 text-center">
                  <CalendarDays className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <h3 className="font-bold text-slate-800 text-base">Clear Reservation Dashboard</h3>
                  <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                    You have not scheduled any appointments yet. Select "Available Offerings" top-tab and launch high-quality bookings.
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {appointments.map((apt) => {
                    // Badge styles for different statuses
                    const statusStyles: { [key: string]: string } = {
                      pending: 'bg-amber-50 border-amber-200 text-amber-700',
                      accepted: 'bg-teal-50 border-teal-200 text-teal-700',
                      rejected: 'bg-rose-50 border-rose-200 text-rose-700',
                      completed: 'bg-emerald-50 border-emerald-200 text-emerald-700',
                      cancelled: 'bg-slate-50 border-slate-200 text-slate-500'
                    };

                    return (
                      <div 
                        key={apt.id}
                        className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/50 transition-all"
                        id={`apt_row_${apt.id}`}
                      >
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="font-bold text-slate-900 text-sm">{apt.serviceName}</h3>
                            <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 border rounded-full ${statusStyles[apt.status] || 'bg-slate-50'}`}>
                              <span className="h-1.5 w-1.5 rounded-full bg-current"></span>
                              {apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
                            </span>
                          </div>

                          <p className="text-xs font-medium text-slate-500">
                            By: <span className="font-bold text-slate-700">{apt.providerName}</span>
                          </p>

                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400 font-medium pt-1">
                            <span className="flex items-center gap-1 text-slate-600"><Calendar className="w-3.5 h-3.5 text-slate-400" /> {apt.date}</span>
                            <span className="flex items-center gap-1 text-slate-600"><Clock className="w-3.5 h-3.5 text-slate-400" /> {apt.timeSlot} ({apt.duration} mins)</span>
                            <span className="flex items-center gap-1 text-indigo-600 font-bold"><CreditCard className="w-3.5 h-3.5" /> ${apt.price}</span>
                          </div>

                          {apt.notes && (
                            <div className="mt-2 text-xs text-slate-500 bg-slate-50 p-2 rounded border border-slate-100 flex items-start gap-1">
                              <MessageSquare className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
                              <span>Notes: <span className="italic">"{apt.notes}"</span></span>
                            </div>
                          )}
                        </div>

                        <div className="sm:text-right flex items-center justify-end">
                          {['pending', 'accepted'].includes(apt.status) && (
                            <button
                              onClick={() => setCancelCandidateId(apt.id)}
                              className="text-xs bg-rose-50 border border-rose-100 hover:bg-rose-100 text-rose-700 font-semibold px-3 py-1.5 rounded-lg transition-all"
                              id={`btn_cancel_apt_${apt.id}`}
                            >
                              Cancel Booking
                            </button>
                          )}

                          {apt.status === 'completed' && (
                            <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 border border-emerald-100 rounded-lg px-2.5 py-1.5 flex items-center gap-1">
                              <CheckCircle className="w-3.5 h-3.5" /> Session Completed
                            </span>
                          )}

                          {apt.status === 'rejected' && (
                            <span className="text-[11px] text-rose-500 italic">Rejected by Provider</span>
                          )}

                          {apt.status === 'cancelled' && (
                            <span className="text-[11px] text-slate-400 italic">Cancelled by You</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          )}
        </div>

      </main>

      {/* Cancellation Confirmation Dialog Overlay */}
      <AnimatePresence>
        {cancelCandidateId && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50"
            id="cancel_modal_overlay"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 10 }}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100"
              id="cancel_modal_content"
            >
              <div className="flex items-center gap-3 text-rose-600 mb-4">
                <div className="h-10 w-10 rounded-full bg-rose-50 flex items-center justify-center text-rose-600 shrink-0">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Cancel Appointment?</h3>
              </div>
              <p className="text-sm text-slate-500 leading-relaxed">
                Are you absolutely sure you want to cancel this booking? This slot will instantly become available for other clients to reserve. Historical appointments cannot be restored.
              </p>
              
              <div className="mt-6 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setCancelCandidateId(null)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-lg text-sm font-semibold hover:bg-slate-50 transition-all"
                  id="btn_cancel_modal_abort"
                >
                  Keep Booking
                </button>
                <button
                  type="button"
                  onClick={() => cancelCandidateId && cancelAppointment(cancelCandidateId)}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-sm font-semibold shadow-sm hover:shadow-rose-600/10 transition-all"
                  id="btn_cancel_modal_confirm"
                >
                  Yes, Cancel Session
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Modern Dialog Exception Alert Overlay */}
      <AnimatePresence>
        {errorNotification && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50"
            id="error_modal_overlay"
          >
            <motion.div 
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-white rounded-xl max-w-sm w-full p-5 shadow-xl border border-slate-100"
            >
              <div className="flex items-center gap-3 text-rose-600 mb-3">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <h3 className="font-bold text-sm text-slate-900">Operation Error</h3>
              </div>
              <p className="text-xs text-slate-500 mb-4">{errorNotification}</p>
              <button
                type="button"
                onClick={() => setErrorNotification(null)}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg transition-all"
              >
                Close Window
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <footer className="bg-white border-t border-slate-200 py-6 mt-12 text-center text-xs text-slate-400">
        <p>&copy; {new Date().getFullYear()} BookEase Online Appointment Operations. All rights reserved.</p>
        <p className="mt-1">Designed with precision grid layout for therapists, wellness clinics, and consulting practitioners.</p>
      </footer>
    </div>
  );
}
