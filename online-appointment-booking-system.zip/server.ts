import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { dbManager } from './server-db';
import { User } from './src/types';

// Extend express Request to support custom user attribute safely
interface AuthenticatedRequest extends Request {
  user?: User;
  token?: string;
}

// Authentication middleware
function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer <token>

  if (!token) {
    res.status(401).json({ error: 'Access denied. Authorization token is required.' });
    return;
  }

  const user = dbManager.getUserByToken(token);
  if (!user) {
    res.status(401).json({ error: 'Access denied. Invalid or expired token.' });
    return;
  }

  req.user = user;
  req.token = token;
  next();
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Support JSON parsing
  app.use(express.json());

  // --- API ROUTES ---

  // Health check
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // User registration
  app.post('/api/auth/register', (req: Request, res: Response) => {
    try {
      const { name, email, role, password } = req.body;
      if (!name || !email || !role || !password) {
        res.status(400).json({ error: 'All fields (name, email, role, password) are required.' });
        return;
      }
      if (role !== 'customer' && role !== 'provider') {
        res.status(400).json({ error: 'Invalid role. Must be customer or provider.' });
        return;
      }
      if (password.length < 6) {
        res.status(400).json({ error: 'Password must be at least 6 characters long.' });
        return;
      }

      const user = dbManager.registerUser(name, email, role, password);
      // Authenticate directly after registration and return token
      const authResult = dbManager.authenticateUser(email, password);
      res.status(201).json(authResult);
    } catch (error: any) {
      res.status(400).json({ error: error.message || 'Registration failed.' });
    }
  });

  // User credentials login
  app.post('/api/auth/login', (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        res.status(400).json({ error: 'Email and password are required.' });
        return;
      }

      const authResult = dbManager.authenticateUser(email, password);
      res.json(authResult);
    } catch (error: any) {
      res.status(401).json({ error: error.message || 'Login failed.' });
    }
  });

  // Retrieve current active user profile
  app.get('/api/auth/me', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
    res.json({ user: req.user });
  });

  // User logout session termination
  app.post('/api/auth/logout', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
    if (req.token) {
      dbManager.logoutUser(req.token);
    }
    res.json({ success: true, message: 'Successfully logged out.' });
  });

  // --- SERVICE ROUTES ---

  // Retrive list of available booking services
  app.get('/api/services', (req: Request, res: Response) => {
    const services = dbManager.getServices();
    res.json(services);
  });

  // Add new business service
  app.post('/api/services', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
    try {
      const { user } = req;
      if (!user || user.role !== 'provider') {
        res.status(430).json({ error: 'Access denied. Only service providers can add offerings.' });
        return;
      }

      const { name, description, duration, price, category } = req.body;
      if (!name || !description || !duration || !price || !category) {
        res.status(400).json({ error: 'All fields (name, description, duration, price, category) are required.' });
        return;
      }

      const priceNum = Number(price);
      const durationNum = Number(duration);

      if (isNaN(priceNum) || priceNum <= 0) {
        res.status(400).json({ error: 'Price must be a valid number greater than zero.' });
        return;
      }

      if (isNaN(durationNum) || durationNum <= 0) {
        res.status(400).json({ error: 'Duration must be a valid number of minutes.' });
        return;
      }

      const newService = dbManager.createService({
        name,
        description,
        duration: durationNum,
        price: priceNum,
        category,
        providerId: user.id,
        providerName: user.name
      });

      res.status(201).json(newService);
    } catch (error: any) {
      res.status(400).json({ error: error.message || 'Failed to create service.' });
    }
  });

  // Update existing business service
  app.put('/api/services/:id', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
    try {
      const { user } = req;
      if (!user || user.role !== 'provider') {
        res.status(403).json({ error: 'Access denied. Only service providers can edit offerings.' });
        return;
      }

      const { id } = req.params;
      const { name, description, duration, price, category } = req.body;

      const updates: any = {};
      if (name) updates.name = name;
      if (description) updates.description = description;
      if (category) updates.category = category;
      
      if (duration !== undefined) {
        const durationNum = Number(duration);
        if (isNaN(durationNum) || durationNum <= 0) {
          res.status(400).json({ error: 'Duration must be a positive number.' });
          return;
        }
        updates.duration = durationNum;
      }

      if (price !== undefined) {
        const priceNum = Number(price);
        if (isNaN(priceNum) || priceNum <= 0) {
          res.status(400).json({ error: 'Price must be a positive number.' });
          return;
        }
        updates.price = priceNum;
      }

      const updated = dbManager.updateService(id, user.id, updates);
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ error: error.message || 'Service update failed.' });
    }
  });

  // Remove existing business service
  app.delete('/api/services/:id', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
    try {
      const { user } = req;
      if (!user || user.role !== 'provider') {
        res.status(403).json({ error: 'Access denied. Only service providers can delete offerings.' });
        return;
      }

      const { id } = req.params;
      dbManager.deleteService(id, user.id);
      res.json({ success: true, message: 'Service removed successfully.' });
    } catch (error: any) {
      res.status(400).json({ error: error.message || 'Service removal failed.' });
    }
  });

  // --- APPOINTMENT ROUTES ---

  // Get appointments list for active user
  app.get('/api/appointments', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
    try {
      const { user } = req;
      if (!user) {
        res.status(401).json({ error: 'Session expired.' });
        return;
      }

      const appointments = dbManager.getAppointments(user.id, user.role);
      res.json(appointments);
    } catch (error: any) {
      res.status(400).json({ error: error.message || 'Failed to capture appointments.' });
    }
  });

  // Post a new appointment booking
  app.post('/api/appointments', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
    try {
      const { user } = req;
      if (!user || user.role !== 'customer') {
        res.status(403).json({ error: 'Access denied. Only customers can book appointments.' });
        return;
      }

      const { serviceId, date, timeSlot, notes } = req.body;
      if (!serviceId || !date || !timeSlot) {
        res.status(400).json({ error: 'Service, Date, and Time Slot are required.' });
        return;
      }

      const appointment = dbManager.bookAppointment({
        serviceId,
        customerId: user.id,
        customerName: user.name,
        customerEmail: user.email,
        date,
        timeSlot,
        notes
      });

      res.status(201).json(appointment);
    } catch (error: any) {
      res.status(400).json({ error: error.message || 'Booking failed to save.' });
    }
  });

  // Update status (Accept, Reject, Cancel, Complete)
  app.put('/api/appointments/:id/status', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
    try {
      const { user } = req;
      if (!user) {
        res.status(401).json({ error: 'Session expired.' });
        return;
      }

      const { id } = req.params;
      const { status } = req.body;

      if (!status) {
        res.status(400).json({ error: 'Status string is required.' });
        return;
      }

      const updated = dbManager.updateAppointmentStatus(id, user.id, user.role, status);
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ error: error.message || 'Failed to update reservation.' });
    }
  });

  // --- FRONTEND ASSET SERVING & FALLBACKS ---

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    // Serve index.html for all SPA routes in production
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Node Server booting at http://localhost:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Fatal initialization failure:', err);
});
