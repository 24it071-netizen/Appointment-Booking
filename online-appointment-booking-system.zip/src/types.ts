export interface User {
  id: string;
  name: string;
  email: string;
  role: 'customer' | 'provider';
  createdAt: string;
}

export interface Service {
  id: string;
  name: string;
  description: string;
  duration: number; // in minutes
  price: number;
  category: string;
  providerId: string;
  providerName: string;
  createdAt: string;
}

export type AppointmentStatus = 'pending' | 'accepted' | 'rejected' | 'completed' | 'cancelled';

export interface Appointment {
  id: string;
  serviceId: string;
  serviceName: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  providerId: string;
  providerName: string;
  date: string; // YYYY-MM-DD
  timeSlot: string; // "09:00", "13:30", etc.
  duration: number; // in minutes
  price: number;
  status: AppointmentStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuthResponse {
  user: User;
  token: string;
}
