import React, { useState, useEffect } from 'react';
import { User, Service, Appointment } from '../types';
import { 
  Calendar, Clock, CheckCircle, XCircle, AlertCircle, 
  HelpCircle, Search, LogOut, DollarSign, Tag, ListFilter, 
  Plus, CalendarDays, ClipboardList, CreditCard, RefreshCw, 
  Trash2, Edit, Check, X, Ban, ShoppingBag, BarChart3, Users, 
  TrendingUp, MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ProviderDashboardProps {
  user: User;
  onLogout: () => void;
  token: string;
}

export default function ProviderDashboard({ user, onLogout, token }: ProviderDashboardProps) {
  const [services, setServices] = useState<Service[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loadingServices, setLoadingServices] = useState(false);
  const [loadingAppointments, setLoadingAppointments] = useState(false);

  // Stats
  const [stats, setStats] = useState({
    totalRevenue: 0,
    acceptedAppointments: 0,
    pendingAppointments: 0,
    completedAppointments: 0
  });

  // Services Management State
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [serviceName, setServiceName] = useState('');
  const [serviceDesc, setServiceDesc] = useState('');
  const [serviceDuration, setServiceDuration] = useState('65');
  const [servicePrice, setServicePrice] = useState('100');
  const [serviceCategory, setServiceCategory] = useState('Health & Wellness');
  const [serviceError, setServiceError] = useState<string | null>(null);
  const [isSavingService, setIsSavingService] = useState(false);

  // Tabs
  const [activeTab, setActiveTab] = useState<'appointments' | 'services' | 'insights'>('appointments');
  const [appointmentsFilter, setAppointmentsFilter] = useState<'all' | 'pending' | 'accepted' | 'completed' | 'cancelled' | 'rejected'>('all');

  // Interactive non-blocking confirmation dialog state
  const [deleteCandidateId, setDeleteCandidateId] = useState<string | null>(null);
  const [errorNotification, setErrorNotification] = useState<string | null>(null);

  const loadData = async () => {
    setLoadingServices(true);
    setLoadingAppointments(true);
    try {
      // Load services
      const srvResponse = await fetch('/api/services');
      const srvData = await srvResponse.json();
      if (srvResponse.ok) {
        // Only keep services matching this active provider
        const myServices = srvData.filter((s: Service) => s.providerId === user.id);
        setServices(myServices);
      }

      // Load appointments
      const aptResponse = await fetch('/api/appointments', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const aptData = await aptResponse.json();
      if (aptResponse.ok) {
        // Sorted newest date first
        const sorted = aptData.sort((a: Appointment, b: Appointment) => {
          return new Date(`${b.date}`).getTime() - new Date(`${a.date}`).getTime();
        });
        setAppointments(sorted);

        // Generate analytics metrics
        let rev = 0;
        let pending = 0;
        let accepted = 0;
        let completed = 0;

        sorted.forEach((apt: Appointment) => {
          if (apt.status === 'completed') {
            rev += apt.price;
            completed += 1;
          } else if (apt.status === 'pending') {
            pending += 1;
          } else if (apt.status === 'accepted') {
            accepted += 1;
          }
        });

        setStats({
          totalRevenue: rev,
          pendingAppointments: pending,
          acceptedAppointments: accepted,
          completedAppointments: completed
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingServices(false);
      setLoadingAppointments(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [token]);

  // Appointment decision status adjustments
  const updateAppointmentStatus = async (appointmentId: string, newStatus: string) => {
    try {
      const response = await fetch(`/api/appointments/${appointmentId}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ status: newStatus })
      });

      if (response.ok) {
        loadData();
      } else {
        const data = await response.json();
        alert(data.error || 'Failed to update reservation status.');
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Create or update service action handler
  const handleSaveService = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceName || !serviceDesc || !serviceDuration || !servicePrice || !serviceCategory) {
      setServiceError('Please populate all available service characteristics.');
      return;
    }

    setIsSavingService(true);
    setServiceError(null);

    const isEdit = !!editingService;
    const endpoint = isEdit ? `/api/services/${editingService.id}` : '/api/services';
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const response = await fetch(endpoint, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          name: serviceName,
          description: serviceDesc,
          duration: Number(serviceDuration),
          price: Number(servicePrice),
          category: serviceCategory
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit service modifications.');
      }

      // Reset
      setServiceName('');
      setServiceDesc('');
      setServiceDuration('60');
      setServicePrice('100');
      setServiceCategory('Health & Wellness');
      setShowAddForm(false);
      setEditingService(null);
      loadData();
    } catch (err: any) {
      setServiceError(err.message || 'Error occurred while saving your service choice.');
    } finally {
      setIsSavingService(false);
    }
  };

  const deleteService = async (id: string) => {
    try {
      const response = await fetch(`/api/services/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        loadData();
        setDeleteCandidateId(null);
      } else {
        const data = await response.json();
        setErrorNotification(data.error || 'Service removal was rejected.');
      }
    } catch (e) {
      console.error(e);
      setErrorNotification('Communication with the server was interrupted. Please retry.');
    }
  };

  const startEditService = (srv: Service) => {
    setEditingService(srv);
    setServiceName(srv.name);
    setServiceDesc(srv.description);
    setServiceDuration(String(srv.duration));
    setServicePrice(String(srv.price));
    setServiceCategory(srv.category);
    setShowAddForm(true);
    setServiceError(null);
  };

  const filteredAppointments = appointments.filter(apt => {
    if (appointmentsFilter === 'all') return true;
    return apt.status === appointmentsFilter;
  });

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800" id="provider_dashboard_view">
      {/* Provider Dashboard Top bar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm" id="prov_header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-indigo-700 flex items-center justify-center text-white font-bold" id="logo_container">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xl font-bold tracking-tight text-slate-900">BookEase</span>
                <span className="ml-2 text-xs bg-indigo-100 border border-indigo-200 text-indigo-700 font-semibold px-2 py-0.5 rounded-full">Provider Portal</span>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-semibold text-slate-800">{user.name}</p>
                <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-500 uppercase tracking-wide font-bold">Business Owner</span>
              </div>
              <div className="h-9 w-px bg-slate-200 hidden sm:block"></div>
              <button
                onClick={onLogout}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-50 transition-all text-sm font-medium"
                id="btn_logout_prov"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* Analytics overview cards */}
      <div className="bg-slate-900 text-white py-6 border-b border-slate-800" id="prov_analytics_marquee">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-800 select-none">
              <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Historical Earnings</p>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-2xl sm:text-3xl font-extrabold text-white">${stats.totalRevenue}</span>
                <span className="text-xs text-emerald-400 font-bold flex items-center"><TrendingUp className="w-3 h-3 inline" /> Gross Received</span>
              </div>
            </div>

            <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-800 select-none">
              <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Needs Decision</p>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-2xl sm:text-3xl font-extrabold text-amber-400">{stats.pendingAppointments}</span>
                <span className="text-xs text-amber-500 font-semibold">Pending Slots</span>
              </div>
            </div>

            <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-800 select-none">
              <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Scheduled Ahead</p>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-2xl sm:text-3xl font-extrabold text-teal-400">{stats.acceptedAppointments}</span>
                <span className="text-xs text-teal-500 font-semibold">Confirmed Up next</span>
              </div>
            </div>

            <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-800 select-none">
              <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Sessions Fulfilled</p>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-2xl sm:text-3xl font-extrabold text-indigo-400">{stats.completedAppointments}</span>
                <span className="text-xs text-indigo-500 font-semibold">Archived Sessions</span>
              </div>
            </div>

          </div>
        </div>
      </div>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Navigation tabs */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div className="flex bg-slate-100 p-1 rounded-xl" id="provider_workspace_tabs">
            <button
              onClick={() => {
                setActiveTab('appointments');
                setShowAddForm(false);
                setEditingService(null);
              }}
              className={`flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'appointments'
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              id="prov_tab_bookings"
            >
              <CalendarDays className="w-4 h-4" />
              Manage Bookings
            </button>
            <button
              onClick={() => {
                setActiveTab('services');
                setEditingService(null);
              }}
              className={`flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'services'
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              id="prov_tab_offerings"
            >
              <ShoppingBag className="w-4 h-4" />
              Offered Services ({services.length})
            </button>
          </div>

          {activeTab === 'services' && !showAddForm && (
            <button
              onClick={() => {
                setEditingService(null);
                setServiceName('');
                setServiceDesc('');
                setServiceDuration('60');
                setServicePrice('100');
                setServiceCategory('Health & Wellness');
                setShowAddForm(true);
                setServiceError(null);
              }}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow hover:shadow-indigo-600/10 flex items-center gap-2"
              id="btn_trigger_add_service"
            >
              <Plus className="w-4 h-4" /> Create Service Offering
            </button>
          )}
        </div>

        {/* Dynamic Display Area */}
        <div id="provider_active_screen">
          {activeTab === 'appointments' ? (
            
            /* Bookings display card list */
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              
              {/* Header Filter controller */}
              <div className="p-5 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50/50">
                <div>
                  <h2 className="text-base font-bold text-slate-900">Live Custom Appointments</h2>
                  <p className="text-xs text-slate-400">Validate requests instantly. Accept slot proposals, reject collision items, or mark completed.</p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider mr-1">Status:</span>
                  {(['all', 'pending', 'accepted', 'completed', 'cancelled', 'rejected'] as const).map((filterVal) => (
                    <button
                      key={filterVal}
                      onClick={() => setAppointmentsFilter(filterVal)}
                      className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${
                        appointmentsFilter === filterVal
                          ? 'bg-indigo-600 text-white border-indigo-600'
                          : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
                      }`}
                      id={`filter_btn_${filterVal}`}
                    >
                      {filterVal.charAt(0).toUpperCase() + filterVal.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Appointments List */}
              {loadingAppointments ? (
                <div className="py-20 text-center">
                  <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin mx-auto mb-3" />
                  <p className="text-sm font-medium text-slate-400">Loading client bookings...</p>
                </div>
              ) : filteredAppointments.length === 0 ? (
                <div className="py-20 text-center border-t border-slate-100">
                  <ClipboardList className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <h3 className="font-bold text-slate-800 text-base">Empty Ledger matching filter</h3>
                  <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                    You have no active appointments booked in this state. Adjust filter options or publish new services.
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100" id="appointments_ledger">
                  {filteredAppointments.map((apt) => {
                    // Styles for reservation items
                    const badgeStyles: { [key: string]: string } = {
                      pending: 'bg-amber-50 border-amber-200 text-amber-700',
                      accepted: 'bg-teal-50 border-teal-200 text-teal-700',
                      rejected: 'bg-rose-50 border-rose-200 text-rose-700',
                      completed: 'bg-emerald-50 border-emerald-200 text-emerald-700',
                      cancelled: 'bg-slate-50 border-slate-200 text-slate-400'
                    };

                    return (
                      <div 
                        key={apt.id}
                        className="p-5 flex flex-col md:flex-row justify-between md:items-center gap-4 hover:bg-slate-50/20 transition-all"
                        id={`prov_apt_card_${apt.id}`}
                      >
                        {/* Summary details */}
                        <div className="space-y-1.5">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-black text-slate-950 text-sm tracking-tight">{apt.serviceName}</span>
                            <span className={`inline-flex items-center gap-1 text-[10px] uppercase font-bold tracking-wide px-2 py-0.5 border rounded-full ${badgeStyles[apt.status] || 'bg-slate-50'}`}>
                              {apt.status}
                            </span>
                          </div>

                          <div className="space-y-0.5 text-xs">
                            <p className="text-slate-500">
                              Client: <span className="font-extrabold text-slate-800">{apt.customerName}</span> (<span className="text-slate-500 italic">{apt.customerEmail}</span>)
                            </p>
                          </div>

                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400 font-medium pt-1">
                            <span className="flex items-center gap-1 text-slate-600 font-semibold"><Calendar className="w-3.5 h-3.5 text-slate-400" /> {apt.date}</span>
                            <span className="flex items-center gap-1 text-slate-600 font-semibold"><Clock className="w-3.5 h-3.5 text-slate-400" /> {apt.timeSlot} ({apt.duration} mins)</span>
                            <span className="flex items-center gap-1 text-emerald-600 font-extrabold"><CreditCard className="w-3.5 h-3.5" /> ${apt.price}</span>
                          </div>

                          {apt.notes && (
                            <div className="mt-2 text-xs bg-slate-50 border border-slate-100 text-slate-600 p-2 rounded-lg flex items-start gap-1">
                              <MessageSquare className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
                              <span>Notes: <span className="italic">"{apt.notes}"</span></span>
                            </div>
                          )}
                        </div>

                        {/* Interactive actions */}
                        <div className="flex flex-wrap items-center justify-start md:justify-end gap-2 bg-transparent shrink-0">
                          {apt.status === 'pending' && (
                            <>
                              <button
                                onClick={() => updateAppointmentStatus(apt.id, 'accepted')}
                                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-sm transition-all"
                                id={`prov_accept_btn_${apt.id}`}
                              >
                                <Check className="w-3.5 h-3.5" /> Accept
                              </button>
                              <button
                                onClick={() => updateAppointmentStatus(apt.id, 'rejected')}
                                className="px-3 py-1.5 bg-rose-50 border border-rose-200 hover:bg-rose-100 text-rose-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all"
                                id={`prov_reject_btn_${apt.id}`}
                              >
                                <X className="w-3.5 h-3.5" /> Reject
                              </button>
                            </>
                          )}

                          {apt.status === 'accepted' && (
                            <>
                              <button
                                onClick={() => updateAppointmentStatus(apt.id, 'completed')}
                                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-sm transition-all"
                                id={`prov_complete_btn_${apt.id}`}
                              >
                                <CheckCircle className="w-3.5 h-3.5" /> Complete Session
                              </button>
                              <button
                                onClick={() => updateAppointmentStatus(apt.id, 'cancelled')}
                                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all"
                                id={`prov_cancel_btn_${apt.id}`}
                              >
                                <Ban className="w-3.5 h-3.5" /> Cancel Slot
                              </button>
                            </>
                          )}

                          {apt.status === 'completed' && (
                            <span className="text-[11px] font-extrabold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-100 flex items-center gap-1">
                              ✓ Earnings Deposited
                            </span>
                          )}

                          {apt.status === 'rejected' && (
                            <span className="text-xs text-rose-500 italic font-medium">Proposal Rejected</span>
                          )}

                          {apt.status === 'cancelled' && (
                            <span className="text-xs text-slate-400 italic">Cancelled Appointment</span>
                          )}
                        </div>

                      </div>
                    );
                  })}
                </div>
              )}

            </div>
          ) : (
            
            /* Services Management Tab */
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8" id="provider_offerings_section">
              
              {/* Form panel columns (Add or Edit Service) */}
              <AnimatePresence>
                {showAddForm && (
                  <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="lg:col-span-1"
                    id="form_offering_creator"
                  >
                    <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs sticky top-24">
                      <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-4">
                        <h2 className="text-base font-bold text-slate-900">
                          {editingService ? 'Edit Service Details' : 'Create New Service Offering'}
                        </h2>
                        <button 
                          onClick={() => {
                            setShowAddForm(false);
                            setEditingService(null);
                          }}
                          className="text-slate-400 hover:text-slate-600 text-sm font-semibold"
                        >
                          Cancel
                        </button>
                      </div>

                      <form onSubmit={handleSaveService} className="space-y-4">
                        
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">Service Name</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g., Deep Tissue Massage Therapy"
                            value={serviceName}
                            onChange={(e) => setServiceName(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
                            id="field_srv_name"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">Category Specialty</label>
                          <select
                            value={serviceCategory}
                            onChange={(e) => setServiceCategory(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-600/20"
                            id="field_srv_cat"
                          >
                            <option value="Health & Wellness">Health & Wellness</option>
                            <option value="Massage & Relaxation">Massage & Relaxation</option>
                            <option value="Alternative Medicine">Alternative Medicine</option>
                            <option value="Consulting & Advisory">Consulting & Advisory</option>
                            <option value="Cosmetics & Therapy">Cosmetics & Therapy</option>
                          </select>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-xs font-bold text-slate-600 block">Duration (mins)</label>
                            <input
                              type="number"
                              required
                              min="5"
                              value={serviceDuration}
                              onChange={(e) => setServiceDuration(e.target.value)}
                              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2"
                              id="field_srv_dur"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-slate-600 block">Pricing USD ($)</label>
                            <input
                              type="number"
                              required
                              min="1"
                              value={servicePrice}
                              onChange={(e) => setServicePrice(e.target.value)}
                              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2"
                              id="field_srv_price"
                            />
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600 block">Public Description</label>
                          <textarea
                            rows={4}
                            required
                            placeholder="Detail what client receives, preparations required, and expectations..."
                            value={serviceDesc}
                            onChange={(e) => setServiceDesc(e.target.value)}
                            className="w-full p-2 border border-slate-200 rounded-lg text-xs focus:outline-none"
                            id="field_srv_desc"
                          />
                        </div>

                        {serviceError && (
                          <div className="p-3 bg-rose-50 border border-rose-100 text-rose-700 rounded-lg text-xs flex items-start gap-1">
                            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                            <span>{serviceError}</span>
                          </div>
                        )}

                        <button
                          type="submit"
                          disabled={isSavingService}
                          className="w-full py-2 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold shadow-sm"
                          id="btn_submit_add_service"
                        >
                          {isSavingService ? 'Saving Offering...' : editingService ? 'Update Service Offering' : 'Publish Service Offering'}
                        </button>

                      </form>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Offerings list column */}
              <div className={showAddForm ? 'lg:col-span-2 space-y-4' : 'lg:col-span-3 space-y-4'}>
                {loadingServices ? (
                  <div className="py-20 text-center bg-white rounded-xl border border-slate-200">
                    <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin mx-auto mb-3" />
                    <p className="text-xs text-slate-400 font-semibold">Gathering your offerings menu...</p>
                  </div>
                ) : services.length === 0 ? (
                  <div className="py-20 text-center bg-white rounded-xl border border-slate-200 border-dashed">
                    <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <h3 className="font-bold text-slate-800 text-base">No Published Offerings Yet</h3>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      Click the "Create Service Offering" button above to publish your first business treatment slot online!
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {services.map((srv) => (
                      <div 
                        key={srv.id}
                        className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-md transition-all flex flex-col justify-between"
                        id={`prov_srv_card_${srv.id}`}
                      >
                        <div>
                          <div className="flex justify-between items-start gap-2 mb-2">
                            <span className="inline-block text-[10px] bg-slate-100 border border-slate-200 text-slate-600 font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                              {srv.category}
                            </span>
                            <span className="text-base font-extrabold text-slate-900">${srv.price}</span>
                          </div>

                          <h3 className="font-black text-slate-900 text-base mb-1 truncate">{srv.name}</h3>
                          <p className="text-xs text-slate-500 mb-3 font-medium">Duration: {srv.duration} mins</p>
                          <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed mb-4">{srv.description}</p>
                        </div>

                        <div className="border-t border-slate-100 pt-3 flex items-center justify-end gap-2 mt-2 bg-transparent">
                          <button
                            onClick={() => startEditService(srv)}
                            className="p-1.5 rounded-lg border border-slate-200 hover:border-slate-300 text-slate-500 hover:text-slate-800 transition-all"
                            title="Edit Service Details"
                            id={`edit_srv_btn_${srv.id}`}
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setDeleteCandidateId(srv.id)}
                            className="p-1.5 rounded-lg border border-rose-100 hover:border-rose-200 text-rose-500 hover:text-rose-700 transition-all"
                            title="Delete Offering"
                            id={`del_srv_btn_${srv.id}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          )}
        </div>

      </main>

      {/* Service Deletion Dialog Overlay */}
      <AnimatePresence>
        {deleteCandidateId && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50"
            id="delete_srv_modal_overlay"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 10 }}
              className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-100"
              id="delete_srv_modal_content"
            >
              <div className="flex items-center gap-3 text-rose-600 mb-4">
                <div className="h-10 w-10 rounded-full bg-rose-50 flex items-center justify-center text-rose-600 shrink-0">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-slate-900">Delete Service Offering?</h3>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                Deleting this offering will stop new client selections. Existing/historical appointments will be fully preserved in logs.
              </p>
              
              <div className="mt-6 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setDeleteCandidateId(null)}
                  className="px-3.5 py-1.5 border border-slate-200 text-slate-600 rounded-lg text-xs font-semibold hover:bg-slate-50 transition-all font-sans"
                  id="btn_delete_modal_abort"
                >
                  Keep Offering
                </button>
                <button
                  type="button"
                  onClick={() => deleteCandidateId && deleteService(deleteCandidateId)}
                  className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold shadow-sm transition-all font-sans"
                  id="btn_delete_modal_confirm"
                >
                  Yes, Remove Offering
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Exception Notification Banner */}
      <AnimatePresence>
        {errorNotification && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50"
            id="provider_error_modal_overlay"
          >
            <motion.div 
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-white rounded-xl max-w-sm w-full p-5 shadow-xl border border-slate-100"
            >
              <div className="flex items-center gap-3 text-rose-600 mb-3">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <h3 className="font-bold text-sm text-slate-900">System Error</h3>
              </div>
              <p className="text-xs text-slate-500 mb-4">{errorNotification}</p>
              <button
                type="button"
                onClick={() => setErrorNotification(null)}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg transition-all"
              >
                Dismiss Modal
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <footer className="bg-slate-900 text-slate-400 py-8 text-center text-xs border-t border-slate-800 mt-12 font-sans">
        <p>&copy; {new Date().getFullYear()} BookEase Service Logistics Systems. All rights reserved.</p>
        <p className="mt-1">Serving clients securely with sandboxed JSON local database integrations in real-time.</p>
      </footer>
    </div>
  );
}
